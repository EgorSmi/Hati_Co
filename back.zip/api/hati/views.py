from django.views.generic import TemplateView

from rest_framework.generics import GenericAPIView
from rest_framework.response import Response
from rest_framework import status

from .models import HatiMeta, Hati
from .serializers import HatiMetaSerializer, HatiSerializer

# from model.main_win import run_win_back
from django_app import settings
from shutil import copyfile


class HatiMetaView(GenericAPIView):
    """
    Получить мета информацию связанную с объявлениями для поиска собак
    """

    queryset = HatiMeta.objects.all()
    serializer_class = HatiMetaSerializer

    def get(self, request, *args, **kwargs):
        model = self.queryset.model()
        serializer = self.serializer_class

        model.save()

        model.meta_animals()
        model.meta_tails()
        model.meta_colors()
        model.meta_breeds()

        meta = serializer(model).data

        model.delete()

        return Response(meta)


class LookMapView(TemplateView):
    """
    Просмотр карты с камерами для датасета
    """

    template_name = "map_dataset.html"


class HatiFindView(GenericAPIView):
    """
    Получение информации об пропавшей собаки и её поиск
    """

    queryset = Hati.objects.all()
    serializer_class = HatiSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        # photo_url = str(settings.BASE_DIR) + serializer.data.get('image')
        # copyfile(photo_url, str(settings.BASE_DIR) + '\\model\\input')
        # make_copy(serializer.validated_data.get('image'))
        # preds = run_win_back()
        return Response(serializer.data, status=status.HTTP_201_CREATED)